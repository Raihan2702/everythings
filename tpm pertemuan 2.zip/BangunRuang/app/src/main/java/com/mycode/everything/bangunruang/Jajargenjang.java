package com.mycode.everything.bangunruang;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Jajargenjang extends AppCompatActivity {
    private EditText et_alas,et_tinggi;
    private Button btn_luas, btn_pindah;
    private TextView tv_hasil;
    private Double sHasil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jajargenjang);
        et_alas = findViewById(R.id.et_alas);
        et_tinggi = findViewById(R.id.et_tinggi);
        btn_luas = findViewById(R.id.btn_volume);
        tv_hasil = findViewById(R.id.tv_hasil);
        btn_pindah = findViewById(R.id.btn_pindah);

        btn_pindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),Segitiga.class);
                intent.putExtra("hasil",sHasil);
                startActivity(intent);
            }
        });

        btn_luas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Double alas = Double.parseDouble(et_alas.getText().toString());

                    String sAlas = et_alas.getText().toString();
                    if (sAlas.equals(null)) {

                    }else {
                        alas = Double.parseDouble(sAlas);
                    }

                    Double tinggi = Double.parseDouble(et_tinggi.getText().toString());

                    Double luas = alas * tinggi;
                    tv_hasil.setText(String.valueOf(luas));
                    sHasil = luas;

                }catch (Exception e) {
                    Toast.makeText(getApplicationContext(),
                            "Ada yang Error",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
